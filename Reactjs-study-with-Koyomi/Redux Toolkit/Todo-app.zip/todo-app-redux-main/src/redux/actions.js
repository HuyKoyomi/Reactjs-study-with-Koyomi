export const addTodoAction = {
  type: "todoList/addTodo",
  payload: {
    id: 3,
    name: "Learn Javascript",
    completed: false,
    priority: "Low",
  },
};

export const addTodo = (data) => {
  return {
    type: "todoList/addTodo",
    payload: data,
  };
};

export const searchFilterChange = (text) => {
  return {
    type: "filters/searchFilterChange",
    payload: text,
  };
};
