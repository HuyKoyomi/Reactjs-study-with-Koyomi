// const initState = {
//   search: "",
//   status: "All",
//   priority: [],
// };

// const filtersReducer = (state = initState, action) => {
//   console.log({ state, action });
//   switch (action.type) {
//     case "filters/searchFilterChange":
//       return {
//         ...state,
//         search: action.payload,
//       };

//     default:
//       return state;
//   }
// };

// export default filtersReducer;

import { createSlice } from "@reduxjs/toolkit";

export const filtersSlice = createSlice({
  name: "filters",
  initialState: {
    search: "",
    status: "All",
    priority: [],
  },
  reducers: {
    // => { type: 'filters/searchFilterChange' }
    searchFilterChange: (state, action) => {
      // mutation || IMMER ( thu vien cho phep viet co mutation)
      state.search = action.payload;
    },
  },
});
